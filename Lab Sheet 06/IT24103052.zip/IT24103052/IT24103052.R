setwd("C:\\Users\\sukir\\OneDrive\\Desktop\\IT24103052")
getwd()

n <- 50
p <- 0.85
prob_at_least_47 <- 1 - pbinom(46, size=n, prob=p)
prob_at_least_47

lambda <- 12
prob_15_calls <- dpois(15, lambda=lambda)
prob_15_calls