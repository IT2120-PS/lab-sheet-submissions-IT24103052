
setwd("C:\\Users\\sukir\\OneDrive\\Desktop\\Lab5")   
delivery <- read.table("Exercise - Lab 05.txt", header = FALSE)
colnames(delivery) <- c("DeliveryTimes")

delivery$DeliveryTimes <- as.numeric(as.character(delivery$DeliveryTimes))


breaks_seq2 <- seq(20, 70, length.out = 10)   
hist(delivery$DeliveryTimes,
     breaks = breaks_seq2,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Times (minutes)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")


summary(delivery$DeliveryTimes)


hist_data2 <- hist(delivery$DeliveryTimes, breaks = breaks_seq2, right = FALSE, plot = FALSE)
cum_freq2 <- cumsum(hist_data2$counts)


plot(hist_data2$breaks[-1], cum_freq2, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Times (minutes)",
     ylab = "Cumulative Frequency",
     col = "red")
