setwd("C:/Users/sukir/OneDrive/Desktop/IT24103052")
install.packages("readxl")
library(readxl)
df <- read.csv("C://Users/sukir/OneDrive/Desktop/IT24103052/Data.csv", header=TRUE)
print(df)

data_mat <- as.matrix(df[ , -1])
rownames(data_mat) <- df[[1]]
print(data_mat)

test <- chisq.test(data_mat, correct = FALSE)
print(test)

cat("\nExpected counts:\n")
print(test$expected)


cat("\nStandardized residuals:\n")
residuals <- (test$observed - test$expected) / sqrt(test$expected)
print(round(residuals, 2))

png("C:\Users\sukir\OneDrive\Desktop\IT24103052.png", width = 1200, height = 800)

mosaicplot(data_mat, main = "Task vs Who Performs It",
           color = TRUE, las = 2, cex.axis = 0.8)

dev.off()  

if (test$p.value < 0.05) {
  cat("\nConclusion: Reject H0 — Task and person performing are associated.\n")
} else {
  cat("\nConclusion: Fail to reject H0 — No significant relationship.\n")
}

