setwd("C:\\Users\\it24103052\\Desktop\\It24103052")
getwd()
# Problem 1
a <- 0
b <- 40
x1 <- 10
x2 <- 25
prob_uniform <- (x2 - x1) / (b - a)
prob_uniform

# Problem 2
lambda <- 3
x <- 2
prob_exponential <- pexp(x, rate=lambda)
prob_exponential

# Problem 3
mu <- 100
sigma <- 15
z <- (130 - mu) / sigma
prob_iq_above_130 <- 1 - pnorm(130, mean=mu, sd=sigma)
prob_iq_above_130
iq_95th_percentile <- qnorm(0.95, mean=mu, sd=sigma)
iq_95th_percentile
