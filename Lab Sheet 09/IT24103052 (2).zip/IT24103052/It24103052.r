setwd("C:\\Users\\sukir\\OneDrive\\Desktop\\IT24103052")

# Question 1
set.seed(123)
sample_data <- rnorm(25, mean = 45, sd = 2)
sample_data


t_test_result <- t.test(sample_data, mu = 46, alternative = "less")
t_test_result
